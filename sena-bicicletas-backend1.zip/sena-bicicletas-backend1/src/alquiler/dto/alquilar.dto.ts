export class AlquilarDto {
  usuarioId: number;
  biciId: number;
  fechaInicio: string; // formato YYYY-MM-DD
}