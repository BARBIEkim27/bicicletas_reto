import { IsInt, IsNotEmpty } from 'class-validator';

export class AlquilarDto {
  @IsInt()
  usuarioId: number;

  @IsInt()
  biciId: number;

  @IsNotEmpty()
  fechaInicio: string; // 'YYYY-MM-DD'
}
