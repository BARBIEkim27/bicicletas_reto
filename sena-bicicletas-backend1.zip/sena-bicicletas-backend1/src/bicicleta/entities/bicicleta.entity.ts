import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Alquiler } from '../../alquiler/entities/alquiler.entity';

@Entity('bicicleta')
export class Bicicleta {
  @PrimaryGeneratedColumn()
  id_bicicleta: number;

  @Column({ length: 50 })
  marca: string;

  @Column({ length: 30 })
  color: string;

  @Column({ length: 30 })
  estado: string;

  @Column('decimal', { precision: 10, scale: 2 })
  precio_alquiler: number;

  @Column({ default: true })
  disponible: boolean;

  @Column('decimal', { precision: 10, scale: 7, nullable: true })
  lat: number;

  @Column('decimal', { precision: 10, scale: 7, nullable: true })
  lng: number;

  @OneToMany(() => Alquiler, a => a.fk_id_bicicleta)
  alquileres: Alquiler[];
}
